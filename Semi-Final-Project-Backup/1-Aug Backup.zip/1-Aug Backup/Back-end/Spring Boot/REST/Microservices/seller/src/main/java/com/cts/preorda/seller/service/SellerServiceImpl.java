package com.cts.preorda.seller.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.preorda.seller.model.Seller;
import com.cts.preorda.seller.repository.SellerRepository;

@Service
public class SellerServiceImpl implements SellerService{
	private static List<Seller> sellers = new ArrayList<>();

	@Autowired
	SellerRepository sellerRepo;

	@Override
	public Seller storeSellerDetails(Seller seller) {
		return sellerRepo.save(seller);

	}
	
	@Override
	public void update(int seller_Id, Seller seller) {
		
		sellers = sellers.stream().map(b ->{
			if(b.getSeller_id()==seller_Id) {
				b.setSeller_name(seller.getSeller_name());
				b.setPhone_number(seller.getPhone_number());
				//b.setEmail(customer.getEmail());
				//b.setPassword(customer.getPassword());
				b.setHouse_no(seller.getHouse_no());
				b.setStreet(seller.getStreet());
				b.setCity(seller.getCity());
				b.setPincode(seller.getPincode());
				b.setState(seller.getState());
				b.setCountry(seller.getCountry());
				
			}
			return b;
		}).collect(Collectors.toList());
		 sellerRepo.save(seller);
	}
	public Seller getSeller(int seller_Id) {
		Seller seller = sellerRepo.getSeller(seller_Id);
		return seller;
	}
		
	
}
