package com.cts.preorda.seller.exception;


public enum Exceptions {
	NAME_EXIST("APP001","Product Name already Exist"),
	NO_AVAILABLE_PRODUCT("APP002","PRODUCT IS UNAVAILABLE");
	public final String errorCode;
	public final String errorMessage;
	
	private Exceptions(String errorCode, String errorMessage) {
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
	}

}
