package com.cts.preorda.seller.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.service.ProductsService;

@RestController
@RequestMapping("/seller")
@CrossOrigin(origins = "http://localhost:3000/")
public class SellerProductsController {
	
//	@Autowired
//	public ProductsService productsService;
//	
//	@GetMapping("/products")
//	public List<Products> getAllProducts(){
//		
//		List<Products> products = productsService.getAllProducts();
// 		return products;
//	}
//	
//
//	@GetMapping("/products/{id}")
//	public Products getProducts(@PathVariable("id") int id) {
//		
//		Products product = productsService.getProducts(id);
//		System.out.println(product);
//		return product;
//	}
//
//	
//	@PostMapping("/products/save")
//	public String saveProducts(@RequestBody Products product) {
//		productsService.saveProducts(product);
//		return "Product saved successfully";
//	}
//	
//
////	@
////	public String edit-product(@PathVariable("id")int id){
////		
////	}
//	@PutMapping("/edit-products/{id}")  
//	private Products update(@RequestBody Products product,@PathVariable("id")int id)   
//	{  
//    productsService.update(product, id);  
//	return product;  
//	}  
//	
//	
//	  
//	
//	
//	
//	
//	@DeleteMapping("/del-products/{id}")
//
//	public void deleteProducts(@PathVariable("id") int id) {
//		productsService.deleteProducts(id);
//	}
}
