package com.cts.preorda.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.preorda.customer.model.Schedules;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedules, Integer> {
	
	@Query(value = "select grand_total from orders where order_id = :oid", nativeQuery = true)
	double get_order_total(@Param("oid")int order_id);
	
	@Query(value = "select user from orders where order_id = :oid", nativeQuery = true)
	int get_uid_with_oid(@Param("oid")int order_id);
	

	
	@Query(value = "select username from users where user_id = :uid", nativeQuery = true)
	String get_email_with_uid(@Param("uid")int uid);
	
	@Transactional
	@Modifying
	@Query(value="delete from schedules where order_id = :order_id and schedule_id > 0",nativeQuery = true)
	
	void delete_schedule(@Param("order_id") int order_id);
}
