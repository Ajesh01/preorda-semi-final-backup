package com.cts.preorda.customer;

import java.sql.SQLException;

import org.h2.tools.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.cts.preorda.customer.service.EmailSenderInterf;

@SpringBootApplication
@EnableScheduling
@EnableDiscoveryClient


public class CustomerApplication {

	public static void main(String[] args) throws SQLException {
		
//		Server server = Server.createTcpServer("-tcp","-tcpAllowOthers","-ifNotExists","-pgAllowOthers").start();
//		Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "9092");
		SpringApplication.run(CustomerApplication.class, args);
		
	}
	
	
	@Autowired
	public EmailSenderInterf sender;
	
	
//	@EventListener(ApplicationReadyEvent.class)
//	public void triggerMail() throws MessagingException, IOException {
//		//service.sendSimpleEmail("ecommercesitepreorda@gmail.com", "This is the body", "First mail");
//		List<OrderDetails> li = new ArrayList<>();
//		OrderDetails od = new OrderDetails();
//		od.setProduct_name("shampoo");
//		od.setQuantity(3);
//		od.setSubtotal(50);
//		OrderDetails od1 = new OrderDetails();
//		od1.setProduct_name("soap");
//		od1.setQuantity(3);
//		od1.setSubtotal(50);
//		li.add(od);
//		li.add(od1);
//		sender.sendSimpleEmailWithAttachment("haripulluru05@gmail.com","hari","pulluru","900",li);
//		
//	}
	
}
