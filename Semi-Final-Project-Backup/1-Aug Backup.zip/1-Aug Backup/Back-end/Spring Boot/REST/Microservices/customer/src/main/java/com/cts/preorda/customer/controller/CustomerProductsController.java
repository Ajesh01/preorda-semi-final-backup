package com.cts.preorda.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Products;
import com.cts.preorda.customer.service.ProductsService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:3000/")

public class CustomerProductsController {
	
	@Autowired
	public ProductsService productsService;
	
	@GetMapping("/products")
	public List<Products> getAllProducts(){
		
		List<Products> products = productsService.getAllProducts();
 		return products;
	}
	
	@GetMapping("/products/categories/{categories}")
	public List<Products> getAllProductsByCategory(@PathVariable String categories){
		
		List<Products> products = productsService.getAllProductsByCategory(categories);
 		return products;
	}
	
	@GetMapping(value = "/products/prices1")
    public Iterable<Products> getProductsByPrices() {

        return productsService.findAllByOrderByPriceAsc();
    }
	@GetMapping(value = "/products/prices2")
    public Iterable<Products> getProductsByPricesd() {

        return productsService.findAllByOrderByPriceDesc();
    }
	@GetMapping("/products/categories/price1/{category}")
    public Iterable<Products> getProductsByPricesCata(@PathVariable String category) {

        return productsService.findCatByOrderByPriceAsc(category);
    }
	@GetMapping("/products/categories/price2/{category}")
    public Iterable<Products> getProductsByPricesCatad(@PathVariable String category) {

        return productsService.findCatByOrderByPriceDesc(category);
    }
	
}
