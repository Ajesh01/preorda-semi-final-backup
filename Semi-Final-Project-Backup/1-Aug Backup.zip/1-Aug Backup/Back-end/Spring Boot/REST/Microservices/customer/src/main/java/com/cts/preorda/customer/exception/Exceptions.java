package com.cts.preorda.customer.exception;


public enum Exceptions {
	NAME_EXIST("APP001","Product Name already Exist"),
	LOW_QUANTITY("APP002","PRODUCT IS UNAVAILABLE"),
	MAIL_EXIST("APP003","MAIL ALREADY RESGISTERED");
	public final String errorCode;
	public final String errorMessage;
	
	private Exceptions(String errorCode, String errorMessage) {
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
	}

}
