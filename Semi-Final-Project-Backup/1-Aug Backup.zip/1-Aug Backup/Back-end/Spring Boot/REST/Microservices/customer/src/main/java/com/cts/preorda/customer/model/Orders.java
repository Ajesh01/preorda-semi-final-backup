package com.cts.preorda.customer.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter

public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	public int order_Id; 
	//@Column(nullable=false,length=10)
	@Column(nullable=false,length=10,name = "\"user\"")
	private int user;
	@Column(nullable = false, length = 60)
	private double grand_total;
	@Column(nullable = false, length = 25)
	private int no_of_items;
	@Column(nullable=false,length = 32 )
	private String ordertype;//Scheduled order / Normal
	@Column(length = 32 )
	private String schedule; //Daily / Weekly / Monthly/ Yearly
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date orderPlacedDate;
	
	@Column(nullable=false,length = 32)
	private String status; //Placed / Dispatched / Delivered
	public int getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	public double getGrand_total() {
		return grand_total;
	}
	public void setGrand_total(double grand_total) {
		this.grand_total = grand_total;
	}
	public int getNo_of_items() {
		return no_of_items;
	}
	public void setNo_of_items(int no_of_items) {
		this.no_of_items = no_of_items;
	}
	public String getOrdertype() {
		return ordertype;
	}
	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	public Date getOrderPlacedDate() {
		return orderPlacedDate;
	}
	public void setOrderPlacedDate(Date orderPlacedDate) {
		this.orderPlacedDate = orderPlacedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	

	
	
}
