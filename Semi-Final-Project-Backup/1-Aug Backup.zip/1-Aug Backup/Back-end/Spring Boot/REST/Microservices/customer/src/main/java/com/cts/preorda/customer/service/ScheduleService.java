package com.cts.preorda.customer.service;

import com.cts.preorda.customer.model.Schedules;



public interface ScheduleService {

	public Schedules add_schedule(int uid, int order_id, String frequency);
	public void scheduleOrder();
	
	public String deScheduleOrder(int order_id);
}
