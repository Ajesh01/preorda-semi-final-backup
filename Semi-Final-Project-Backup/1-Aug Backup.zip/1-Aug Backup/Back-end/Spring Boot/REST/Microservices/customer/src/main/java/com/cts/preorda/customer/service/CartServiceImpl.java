package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Cart;
import com.cts.preorda.customer.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{
	@Autowired
	CartRepository cartRepo;

	@Override
	public Cart storeCartDetails(Cart cart) {		
		return cartRepo.save(cart);

	}
	@Override
	public List<Cart> getAllProducts() {
		List<Cart> cart = cartRepo.findAll();
		return cart;
    }
	
	public List<Cart> getMyCartDetails(int user_id) {
		List<Cart> cart = cartRepo.findByUser(user_id);
		return cart;
	}
	
	@Override
	public Cart updateMyCart(Cart cart) {
		return cartRepo.save(cart);
	}
	@Override
	public String removeFromCart(int cart_Id) {
		cartRepo.deleteById(cart_Id);
		return "Removed from cart";
    }
	@Override
	public String emptyCart(int user_id) {
		cartRepo.delete_user_cart(user_id);
		
		return "Emptied cart";
	}

}
