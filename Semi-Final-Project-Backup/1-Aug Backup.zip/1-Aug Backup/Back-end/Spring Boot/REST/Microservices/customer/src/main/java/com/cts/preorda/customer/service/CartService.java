package com.cts.preorda.customer.service;

import com.cts.preorda.customer.model.Cart;


import java.util.List;


public interface CartService {
	public Cart storeCartDetails(Cart cart);
	public List<Cart> getAllProducts();
	public String removeFromCart(int cart_Id);
	public Cart updateMyCart(Cart cart);
	public List<Cart> getMyCartDetails(int user_id);
	public String emptyCart(int user_id);

}
