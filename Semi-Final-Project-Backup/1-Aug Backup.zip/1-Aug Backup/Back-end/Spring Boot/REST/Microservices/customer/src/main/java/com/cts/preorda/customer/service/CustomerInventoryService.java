package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.exception.ApplicationException;
import com.cts.preorda.customer.exception.Exceptions;
import com.cts.preorda.customer.model.Inventory;
import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.model.Products;
import com.cts.preorda.customer.repository.CustomerInventoryRepository;
import com.cts.preorda.customer.repository.OrderDetailsRepository;
import com.cts.preorda.customer.repository.ProductsRepository;

@Service
public class CustomerInventoryService {
	
	
	
	
	@Autowired
	OrderService orderservice;
	
	@Autowired
	ScheduleService scheduleService;

  @Autowired
	OrderDetailsService orderdetailsservice;
  
  @Autowired
	ScheduleService scheduleservice;
	
	@Autowired
	CartService cartService;
	
	@Autowired
	CustomerInventoryRepository inventoryRepo;
	
	@Autowired
	OrderDetailsRepository orderdetailsRepo;
	@Autowired
	ProductsService productservice;
	@Autowired
	ProductsRepository productRepo;
	
	public int decreaseinventory(int order_id) throws ApplicationException
	// pass order table object and get inventory id and quantity
	{
		int new_available=0;
		List<OrderDetails> orderdetails = orderdetailsRepo.findAll();
		int available_status= 1;
		System.out.println("orderdetails:"+orderdetails.size());
		for(int i=0;i<orderdetails.size();i++) {
			if(orderdetails.get(i).getOrderid() == order_id) {
				int product_id = orderdetails.get(i).getProduct_id();
				Products prod= productservice.getProducts(product_id);
				List<Inventory> invn = inventoryRepo.findAll();
int inv_id=0;
			for(int j=0;j<invn.size();j++) {
				if(invn.get(j).getProduct_id() == product_id) {
					inv_id = invn.get(j).getInventory_id();
					//break;
				}	}
			Inventory inv = inventoryRepo.findById(inv_id);
			int available =prod.getQuantity();	
			if(available<=orderdetails.get(i).getQuantity())
			{
				//exception has to be thrown
				
				
				inv.setQuantity(0);				
				prod.setQuantity(0);
				orderdetails.get(i).setQuantity(available);
				inventoryRepo.save(inv);
				productRepo.save(prod);
				orderdetailsRepo.save(orderdetails.get(i));
				available_status = 0;
				throw new ApplicationException(Exceptions.LOW_QUANTITY);
			}	
			
			new_available= available-orderdetails.get(i).getQuantity();
			System.out.println(new_available);
			inv.setQuantity(new_available);				
			prod.setQuantity(new_available);
			inventoryRepo.save(inv);
			productRepo.save(prod);		
			
		}
		
			}
		 return available_status;
		}
	
}
	
	
	
	