package com.cts.preorda.customer.model;

public enum SchedulePreference {
	DAILY ("Daily"),
	WEEKLY ("Weekly"),
	MONTHLY ("Monthly"),
	YEARLY ("Yearly");

		private final String preferencename;
	
		SchedulePreference(String preferencename){
		this.preferencename = preferencename;
	}
}
