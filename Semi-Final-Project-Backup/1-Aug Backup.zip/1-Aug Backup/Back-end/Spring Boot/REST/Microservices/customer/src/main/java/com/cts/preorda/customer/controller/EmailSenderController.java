package com.cts.preorda.customer.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.preorda.customer.service.EmailSenderService;

@RestController
@RequestMapping("/Invoice")
public class EmailSenderController {
	
	@Autowired
	public static EmailSenderService sender;
	
	
	
	
	@GetMapping("/all")
	public static String mailGeneration (ModelAndView model){  
		
		List li = sender.getOrderDetails();
		
		//model = new ModelAndView();
		model.addObject("order", li);
	    
	    return "order/allorder";
	}
}
