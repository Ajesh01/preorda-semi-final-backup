package com.cts.preorda.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.preorda.customer.model.Products;

@Repository
public interface ProductsRepository extends JpaRepository<Products, Integer>{
	
	public List<Products> findByCategory(String name);
	public List<Products> findByName(String name);
	
	@Query("FROM Products ORDER BY price ASC")
    List<Products> findAllByOrderByPriceAsc();
	@Query("FROM Products ORDER BY price DESC")
    List<Products> findAllByOrderByPriceDesc();


	
	public List<Products> findByCategoryOrderByPriceDesc(String name);
	public List<Products> findByCategoryOrderByPriceAsc(String name);
}