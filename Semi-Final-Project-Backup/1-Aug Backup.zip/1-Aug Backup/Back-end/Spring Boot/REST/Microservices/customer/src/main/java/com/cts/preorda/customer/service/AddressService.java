package com.cts.preorda.customer.service;

import java.util.List;

import com.cts.preorda.customer.model.Addresses;


public interface AddressService {

	public List<Addresses> getAddress(int user);
	public Addresses saveAddress(Addresses address);
	
}
