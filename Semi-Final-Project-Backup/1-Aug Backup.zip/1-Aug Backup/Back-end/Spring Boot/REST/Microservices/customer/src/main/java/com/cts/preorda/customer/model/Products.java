package com.cts.preorda.customer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name="products")
@Getter
@Setter
public class Products {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(nullable=false,length=10)
	private double price;
	@Column(nullable=false,length=10)
	private int quantity;
	@Column(nullable=false,length=25)
	private String name;
	@Column(nullable=false,length=25)
	private String brand;
	@Column(nullable=false,length=100)
	private String description;
	@Column(nullable=false,length=50)
	private String category;
	@Lob
	@JsonIgnore
	private byte[] image;
	
	@Transient
	private String imgSrc;

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public String getName() {
		return name;
	}
	public String getCategory() {
		return category;
	}
	

	public void setName(String name) {
		this.name = name;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	public void setCategory(String category) {
		this.category= category;
	}
	
	

	public String getImgSrc() {
		return imgSrc;
	}


	public void setImgSrc(String imgSrc) {
		this.imgSrc = imgSrc;
	}
	
	


	public byte[] getImage() {
		return image;
	}


	public void setImage(byte[] image) {
		this.image = image;
	}


	@Override
	public String toString() {
		return "Products [id=" + id + ", price=" + price + ", quantity=" + quantity + ", product_name=" + name
				+ ", brand=" + brand + ", description=" + description + ", category=" +category + "]";
	}
	
	

	}
