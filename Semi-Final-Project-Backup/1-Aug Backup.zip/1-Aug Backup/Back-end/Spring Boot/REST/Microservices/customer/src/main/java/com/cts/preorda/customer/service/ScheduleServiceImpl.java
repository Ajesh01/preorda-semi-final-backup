package com.cts.preorda.customer.service;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.model.Schedules;
import com.cts.preorda.customer.repository.CustomerRepository;
import com.cts.preorda.customer.repository.OrderDetailsRepository;
import com.cts.preorda.customer.repository.ScheduleRepository;
import com.cts.preorda.customer.service.EmailSenderService;

@Service
public class ScheduleServiceImpl implements ScheduleService{

	
	@Autowired
	ScheduleRepository scheduleRepo;
	
	@Autowired
	OrderDetailsRepository orderdetailsRepo;
	
	@Autowired
	CustomerRepository customerrepo;
	
	@Autowired
	EmailSenderInterf emailsendinterf;
	
	
	public Schedules add_schedule(int uid, int order_id, String frequency) {
		
		Schedules schedule = new Schedules();
		
		schedule.setUser_id(uid);
		schedule.setOrder_id(order_id);
		schedule.setFrequency(frequency);
				
		return scheduleRepo.save(schedule);
	}
	
	
//	@Scheduled(cron = "0 * * ? * *")
	@Scheduled(cron = "0 0 7 * * ?")
	    public void scheduleOrder()
	    {
		 	System.out.println("Scheduler run!");
	        Date d=new Date();  
	        Calendar cal = Calendar.getInstance();
	        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
	        int dayOfWeek = d.getDay();
	        
//	        System.out.println("day of the week is  : "+d.getDay());
		 
		 List<Schedules> schedules = scheduleRepo.findAll();
		 
		 schedules.forEach(
		            (single_sched) -> {
		            	
		            	
//		            		System.out.println("-----\n freq:  "+single_sched.getFrequency());
////		            		System.out.println("check "+ single_sched.getFrequency().equals("DAILY"));
//		            		System.out.println("day of week :  "+dayOfWeek);
//		            		System.out.println("day of month :  "+dayOfMonth);
		            		
		            		if(single_sched.getFrequency().equals("DAILY")) {
		            			try {
									this.get_invoice_data(single_sched.getOrder_id());
								} catch (MessagingException e) {
									e.printStackTrace();
								} catch (IOException e) {
									e.printStackTrace();
								}
		            		}
		            		else if(single_sched.getFrequency().equals("WEEKLY") && dayOfWeek == 0)
		            		{	
		            			try {
									this.get_invoice_data(single_sched.getOrder_id());
								} catch (MessagingException e) {
									e.printStackTrace();
								} catch (IOException e) {
									e.printStackTrace();
								}
		            			
		            		}
		            		else if(single_sched.getFrequency().equals("MONTHLY") && dayOfMonth == 1)
		            		{	try {
								this.get_invoice_data(single_sched.getOrder_id());
							} catch (MessagingException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
		            			
		            		}
		            	
		            	
		            	});
		    }
	 
	 
	 public void get_invoice_data(int orderid) throws MessagingException, IOException {
		 
		 System.out.println("checking order id" + orderid);
		 
		 List<OrderDetails> orderdetails = orderdetailsRepo.findByOrderid(orderid);
		 
		 double total_price = scheduleRepo.get_order_total(orderid);
		 

		 
		 int uid = scheduleRepo.get_uid_with_oid(orderid);
		 
		 Customer cus_details = customerrepo.get_user_details_with_uid(uid);
		 
		 
		 String email = scheduleRepo.get_email_with_uid(uid);
		 
		 
		 
		 // SEND ALL THE ABOVE VARIABLES TO INVOICE METHOD
		 
		 System.out.println("order invoice sent!");
		 
		 String conv_price = Double.toString(total_price);
		 
		 emailsendinterf.sendSimpleEmailWithAttachment(email, cus_details.getFirst_name(),cus_details.getLast_name(), conv_price, orderdetails);
		
			
		 
	 }

		 
	 @Override
		public String deScheduleOrder(int order_id){
			scheduleRepo.delete_schedule(order_id);
			
			return "Descheduled";
		}
	
}
