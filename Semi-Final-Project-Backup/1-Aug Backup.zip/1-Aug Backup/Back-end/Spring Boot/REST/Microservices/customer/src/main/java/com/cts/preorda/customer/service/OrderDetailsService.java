package com.cts.preorda.customer.service;

import java.util.List;

import com.cts.preorda.customer.model.OrderDetails;

public interface OrderDetailsService {
	public OrderDetails storeMyOrderDetails(OrderDetails orderdetails);
	public List<OrderDetails> viewMyOrdersHistory(int orderid);
	
	public String clearOrderDetails(int orderid);
}
