package com.cts.preorda.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.preorda.dao.UserDao;
import com.cts.preorda.exception.ApplicationException;
import com.cts.preorda.exception.Exceptions;
import com.cts.preorda.model.DAOUser;
import com.cts.preorda.model.UserDTO;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		DAOUser user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	
	public DAOUser save(UserDTO user) throws ApplicationException {
		DAOUser newUser = new DAOUser();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		
		
//		int lastUserId = userDao.addingUserId();
//		newUser.setUser_id(lastUserId+1);
		if(userDao.checkUserExist(newUser.getUsername())>0) {
			throw new ApplicationException(Exceptions.MAIL_EXIST);
		}
		return userDao.save(newUser);
	}
	
	public int get_uid( String username) {
		int uid = userDao.get_uid(username);
	
		return uid;
	}
	
	public String get_role( int user_id) {
		
		System.out.println("get_role " +user_id);
		int src = userDao.seller_role_check(user_id);
		int crc = userDao.customer_role_check(user_id);
		System.out.println("src " +src);
		if (src > crc) {
			return "seller";
		}
		return "customer";
		
	}
	
	
}