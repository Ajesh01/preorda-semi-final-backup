package com.cts.preorda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class UserRegistrationAndLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRegistrationAndLoginApplication.class, args);
	}

}
