package com.cts.preorda.model;

import java.io.Serializable;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
	private final String jwttoken;
	private String uname;
	private int uid;
	private String role;

	public JwtResponse(String jwttoken,String uname, int uid, String role) {
		this.jwttoken = jwttoken;
		this.uname = uname;
		this.uid = uid;
		this.role = role;
	}

	public String getToken() {
		return this.jwttoken;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}