import React from "react";
import SellerNavbar from "../seller-nav/Seller-Header";
const About = () => {
  return (
    <div class="minh"> <SellerNavbar/>
    <div className="container">
      <div className="py-4">
        <h1>About Page</h1>
        <p className="lead">
          PREORDA is a ecommerce web application where we can schedule the orders for a given frequency and it automatically orders those selected items.
        </p>
      </div>
    </div>
    </div>
  );
};

export default About;
