import React from 'react';

import Navbar from './Navbar/Navbar';
function Unauthorized() {

    return (
        <div class="minh">
            <Navbar />
            <section className="py-auto">
                <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '55vh' }} >
                    <div class="card p-3 text-center py-4 seller-card" id="sell_reg"><h3 className='text-center line'>Protected Page</h3>
                        <h4 className='text-center'>You are logged in as Customer</h4>
                        <a href='/seller-signup' className="btn btn-danger rounded-pill py-2 d-md-block" >Please Register as Seller</a>
                    </div>
                </div>

            </section >
        </div >

    )
}

export default Unauthorized;