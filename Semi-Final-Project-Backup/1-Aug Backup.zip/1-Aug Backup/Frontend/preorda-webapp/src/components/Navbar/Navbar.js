import React, { useState } from 'react';

import './Navbar.css';
import AuthService from "../services/auth.service";
import { useNavigate } from 'react-router-dom';

function Navbar() {

  let navigate = useNavigate();

  var login_flag = AuthService.get_login_status(AuthService.get_login_status());

  const [login_logout_button, setlogin_logout_button] = useState(login_flag);

  var log_button = "";
  console.log("login status", login_flag);
  // if (login_flag){
  //   log_button = `<button class="btn btn-warning enlarge-quick" type="submit" onClick={handleClick}>Logout</button>`;

  //    }
  //    else{

  //   log_button = `<a  href="/login"><button class="btn btn-warning enlarge-quick" type="submit" >Login</button></a>`;

  //  }

  const handleClick = (e) => {

    setlogin_logout_button(0);
    navigate("/login");
    console.log("login_logout_button", login_logout_button);
    e.preventDefault()
    // console.log("login page : "+ username)
    AuthService.logout().then(
      () => {

        navigate("/login");
        window.location.reload();
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        //   setLoading(false);
        //   setMessage(resMessage);
        console.log(resMessage);

      }
    );
    navigate("/login");
    window.location.reload();

  }
  let Login_Logout_Button = '';
  if (login_logout_button === 1) {
    Login_Logout_Button =
      <div>
        <button class="btn btn-warning enlarge-quick" type="submit" onClick={handleClick}>Logout</button>
      </div>
  } else {
    Login_Logout_Button =
      <div>
        <a href="/login"><button class="btn btn-warning enlarge-quick" type="submit">Login</button></a>
      </div>
  }

  return (
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top" >
      <div class="container-fluid">
        <a class="navbar-brand nav-text" href="#">LOGO</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll">
            <li class="nav-item ">
              <a class="nav-link active nav-text" aria-current="page" href="/">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-text" href="/products">Products</a>
            </li>
            {login_logout_button ?
              <li class="nav-item">
                <a class="nav-link nav-text" href="/profile">My Profile</a>
              </li> : <li></li>}
            {login_logout_button ?
              <li class="nav-item">
                <a class="nav-link nav-text" href="/myorders">My Orders</a>
              </li> : <li></li>}

          </ul>

          <div class="d-flex" >

            {Login_Logout_Button}

            {/* <div dangerouslySetInnerHTML={{ __html: log_button }}/> */}

            <a href="/cart"><button class="btn btn-warning enlarge-quick ms-2" type="submit">Cart</button></a>
          </div>

        </div>
      </div>
    </nav>
  )
}


export default Navbar
