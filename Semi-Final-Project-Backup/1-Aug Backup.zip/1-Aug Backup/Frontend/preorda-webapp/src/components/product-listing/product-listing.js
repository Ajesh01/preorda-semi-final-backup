import React, { useState, useEffect } from 'react';
import Navbar from '../Navbar/Navbar';
import './product-listing.css'
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import ButtonGroup from 'react-bootstrap/esm/ButtonGroup';
import { Navigate } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

var user = localStorage.getItem("user_id");
function ProductListing() {


    const [products, setdisplayproducts] = useState([]);
    const [isActive, setActive] = useState(true);
    let navigate = useNavigate();
    useEffect(() => {
        let mounted = true;
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            if (mounted) {
                setActive(false);
                setdisplayproducts(data);
            }

            console.log("setdisplayproducts", data);

        })

        return () => mounted = false;
    }, []);

    function ProductListingByCategory(category) {
        console.log("Selected Category = ", category);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products/categories/" +
            category, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setActive(true);
            setdisplayproducts(data);
            console.log("setdisplayproducts", data);

        })
    };
    function AllProductsAscSort() {
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products/prices1", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };
    function AllProductsDescSort() {
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products/prices2", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };
    function CatProductsAscSort(category) {
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products/categories/price1/" +
            category, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };
    function CatProductsDescSort(category) {
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products/categories/price2/" +
            category, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };

    function ProductListing() {
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/products", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setActive(false);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };

    const addToCart = (id, name, price) => {
        console.log("addToCart - userid", user);
        const addtocart = {
            "user": parseInt(user),
            "product_Id": id,
            "product_name": name,
            "quantity": 1,
            "price": price
        }

        if (user !== null) {
            console.log('Successfully Added to cart!', addtocart);

            console.log(JSON.stringify(addtocart));
            fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/add", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(addtocart)

            }).then(() => {
                alert(name + "- Successfully Added to cart!");
                console.log(id, name, price);
            })
        }
        else {
            alert("You are not logged in");
            navigate('/login');
        }


    }


    return (
        <div class="minh">
            <Navbar />
            <div className="container-fluid">
                <div className="row">
                    <nav id="sidebarMenu" className="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                        <div className="position-sticky pt-3">
                            <ul className="nav flex-column">
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListing()}>
                                        <span>All</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Electronics")}>
                                        <span>Electronics</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Groceries")}>
                                        <span>Groceries</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Household_Supplies")}>
                                        <span>Household Supplies</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Clothing")}>
                                        <span>Clothing</span>
                                    </a>
                                </li>
                            </ul>


                        </div>
                    </nav>

                    <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                        <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom top-title">
                            <h1 className="h2">Products</h1>
                            {isActive ?
                                <DropdownButton
                                    as={ButtonGroup}
                                    align={{ lg: 'end' }}
                                    variant="secondary"
                                    title="Sortby"
                                    id="dropdown-menu-align-responsive-1"
                                >
                                    {products.map(productList =>
                                        <Dropdown.Menu>
                                            <Dropdown.Item href="#" onClick={e => CatProductsAscSort(productList.category)}>Price(low-high)</Dropdown.Item>
                                            <Dropdown.Item href="#" onClick={e => CatProductsDescSort(productList.category)}>Price(high-low)</Dropdown.Item>
                                        </Dropdown.Menu>
                                    )}
                                </DropdownButton>
                                :
                                <DropdownButton
                                    as={ButtonGroup}
                                    align={{ lg: 'end' }}
                                    variant="secondary"
                                    title="Sortby"
                                    id="dropdown-menu-align-responsive-1"
                                ><Dropdown.Menu>
                                        <Dropdown.Item href="#" onClick={e => AllProductsAscSort()}>Price(low-high)</Dropdown.Item>
                                        <Dropdown.Item href="#" onClick={e => AllProductsDescSort()}>Price(high-low)</Dropdown.Item>
                                    </Dropdown.Menu></DropdownButton>
                            }

                        </div>

                        <div className="album py-5 bg-light ">
                            <div className="container">
                                <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" data-aos="fade-up">
                                    {products.map(productList =>
                                        <div className="col" >
                                            <div className="card p-3 prod-card">

                                                <div className="text-center">

                                                    <img height="150" width="150" src={productList.imgSrc} />{" "}

                                                </div>

                                                <div className="product-details">

                                                    <span className="prod-title">{productList.name}-{productList.brand}</span>
                                                    <span className=" d-block">Rs.{productList.price}/-</span>




                                                    <div className="buttons d-flex  flex-row-reverse" >
                                                        <div className="cart" onClick={e => addToCart(productList.id, productList.name, productList.price)}>To cart<i className="fa fa-shopping-cart"></i></div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>)}
                                </div>
                            </div>
                        </div>

                    </main>
                </div>
            </div>
        </div>
    )

}

export default ProductListing