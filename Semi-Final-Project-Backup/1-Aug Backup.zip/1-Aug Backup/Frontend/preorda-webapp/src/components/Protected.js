import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";


function Protected(props) {
    let customerRole = new String();
    customerRole = '"customer"';
    let userRole = localStorage.getItem("role");
    var user = localStorage.getItem("user_id");
    const { Component } = props;
    const navigate = useNavigate();

    useEffect(() => {
        console.log("Coming....");
        console.log("userRole", userRole);
        console.log("userRole", userRole.length);
        console.log(typeof userRole);
        console.log("customer", customerRole);
        console.log("customer", customerRole.length);
        console.log(typeof customerRole);


        if (userRole === customerRole) {
            console.log("ROLE inside if = customer coming.. ");
            navigate('/unauthorized');
        }
        // if (user !== null) {
        //     console.log("ROLE inside if = customer coming.. ");
        //     navigate('/unauthorized');
        // }


    });
    return (
        <div>
            <Component />
        </div>
    )

}
export default Protected;