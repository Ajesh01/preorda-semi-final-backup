import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import Form from "react-bootstrap/Form";
import Navbar from "../Navbar/Navbar";
import { useNavigate } from "react-router-dom";
var user = localStorage.getItem("user_id");

const UserProfile = (e) => {
  const { customer_Id } = useParams();
  const navigate = useNavigate();
  function handleClick(e) {
    e.preventDefault();
    /*const Customer = {

            first_name, last_name, email, password, phone_number
        }*/
    const Customer = {
      first_name,
      last_name,
      phone_number,
    };
    console.log("customers.customer_Id", customers.customer_Id);
    fetch(
      "http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/edit-customer/" + customers.customer_Id,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customers),
      }
    ).then(() => {
      alert(" Profile updated successfully");
      navigate("/");
    });
  }
  const [customers, setcustomers] = useState({});
  const [customer_id, setCustomer_id] = useState(false);
  const { setValue } = useForm({});

  function setData(fieldName, e) {
    console.log(fieldName);
    console.log(e.target.value);
    e.preventDefault();
    var data = customers;
    data[fieldName] = e.target.value;
    setcustomers({
      customer_Id: data["customer_Id"],
      first_name: data["first_name"],
      last_name: data["last_name"],
      //'email': data['email'],
      //'password': data['password'],
      phone_number: data["phone_number"],
      user_id: user,
    });
    console.log(customers);
  }

  useEffect(() => {
    // get user and set form fields
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/" + user, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    }).then(async (response) => {
      const data = await response.json();
      console.log("User Profile", data);
      //const fields = ['customer_Id', 'first_name', 'last_name', 'email', 'password', 'phone_number'];
      const fields = ["customer_Id", "first_name", "last_name", "phone_number"];
      fields.forEach((field) => setValue(field, data[field]));

      setcustomers(data);
      console.log(customers);
    });
  }, []);
  //  const [product_id, setProduct_id] = useState('')
  const [first_name, setFirst_name] = useState("");
  const [last_name, setLast_name] = useState("");
  //const [email, setEmail] = useState('')
  //const [password, setPassword] = useState('')
  const [phone_number, setPhone_number] = useState("");
  //  const [product_id, setProduct_id] = useState('')
  return (
    <div>
      <Navbar />
      <div className="container card checkout-card">
        <h2 className="text-center">My Profile </h2>
        <hr className="line" />
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <div className="card-body">
              <form>
                <div className="form-group mb-2">
                  <label className="form-label"> First Name :</label>
                  <input
                    type="text"
                    name="first_name"
                    placeholder={customers.first_name}
                    className="form-control"
                    value={customers.first_name}
                    onChange={(e) => setData("first_name", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Last Name :</label>
                  <input
                    type="text"
                    name="last_name"
                    placeholder={customers.last_name}
                    className="form-control"
                    value={customers.last_name}
                    onChange={(e) => setData("last_name", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> Phone number :</label>
                  <input
                    type="text"
                    name="phone_number"
                    placeholder={customers.phone_number}
                    className="form-control"
                    value={customers.phone_number}
                    onChange={(e) => setData("phone_number", e)}
                  ></input>
                </div>

                <table className="table">
                  <td className="align-middle">
                    <button
                      className="btn btn-primary"
                      onClick={(e) => handleClick(e)}
                    >
                      Submit{" "}
                    </button>
                  </td>
                  <td className="align-middle">
                    <Link to="/" className="btn btn-danger">
                      {" "}
                      Cancel{" "}
                    </Link>
                  </td>
                </table>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
