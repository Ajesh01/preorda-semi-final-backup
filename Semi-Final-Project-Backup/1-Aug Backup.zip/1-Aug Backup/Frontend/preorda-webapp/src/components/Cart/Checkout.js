import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Checkout.css";
import Navbar from "../Navbar/Navbar";
import axios from "axios";
import { Alert } from "bootstrap";

var user = localStorage.getItem("user_id");


function loadScript(src) {
	return new Promise((resolve) => {
		const script = document.createElement('script')
		script.src = src
		script.onload = () => {
			resolve(true)
		}
		script.onerror = () => {
			resolve(false)
		}
		document.body.appendChild(script)
	})
}

const __DEV__ = document.domain === 'localhost'

function Checkout() {

  let [isLoaded, setIsLoaded] = useState(false);
  let [err, setErr] = useState(null);
  const [selected, setSelected] = useState("Normal");



	async function displayRazorpay() {
		const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js')

		if (!res) {
			alert('Razorpay SDK failed to load. Are you online?')
			return
		}
    var r_order_id;
		const data = await fetch('http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/payment/getorderid', {
                                method: 'POST',headers: { "Content-Type": "text/plain" },
                              body: ((totalCartPrice+220)*100).toString()
                              }).then((t) =>
                                  t.json()
                                  
                                )

		// console.log(data)

		const options = {
      "key": "rzp_test_uTxY14toaja9lC", // Enter the Key ID generated from the Dashboard
      "amount": ((totalCartPrice+220)*100).toString(), // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
      "currency": "INR",
      "name": "PreOrda",
      "description": "Grand Total",
      "image": "https://example.com/your_logo",
      "order_id": data.order_id, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
      "handler": function (response){
          // alert(response.razorpay_payment_id);
          // alert(response.razorpay_order_id);
          // alert(response.razorpay_signature)
          proceedtoCheckout();
      },
      "prefill": {
          "name": firstName +" " +lastName,
          "email": email,
      },
      "notes": {
          "address": "Preorda Corporate Office"
      },
      "theme": {
          "color": "#E62044"
      }
  };
		const paymentObject = new window.Razorpay(options)
		paymentObject.open()
	}






  // const [selected, setSelected] = useState('Normal');

  let navigate = useNavigate();
  //const [showDropDdown, setshowDropDdown] = useState('false'); //hide/display dropdown
  const [myproducts, setmyproducts] = useState([]); //Order summary
  const [myorders, setmyorders] = useState([]);
  var totalCartPrice = 0;
  var scheduleSelected = null;
  var orderdate = new Date();

  useEffect(() => {
    let mounted = true;

    // console.log("USER", user);
    // console.log("USER", { orderdate });


    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/myproducts/" +
      user, {

      method: "GET",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(myproducts)
    }).then(async (response) => {
      const data = await response.json();
      console.log("data", data);
      // console.log()
      if (mounted) setmyproducts(data);
      console.log("setmyproducts - length of cart", myproducts.length);
      //}
    });

    return () => (mounted = false);
  }, []);

  const handleChange = (event) => {
    console.log(event.target.value);
    setSelected(event.target.value);
    //alert(event.target.value);
    if (event.target.value === "NORMAL") {
      document.getElementById("freq_div").style.display = "none";
    } else {
      document.getElementById("freq_div").style.display = "block";
    }
  };

  const schedulePreference = () => {
    var dropdown1 = document.getElementById("frequency");
    scheduleSelected = dropdown1.options[dropdown1.selectedIndex].value;
    //alert(scheduleSelected);
  };

  const proceedtoCheckout = () => {
    const customer_address2 = {
      house_no,
      street,
      city,
      pincode,
      state,
      user,
    };

    const customer_address = {
      house_no,
      street,
      city,
      pincode,
      state,
      user,
    };

    const placeOrder = {
      house_no: house_no,
      street: street,
      city: city,
      pincode: pincode,
      state: state,
      user: user,
      grand_total: totalCartPrice + 220,
      no_of_items: myproducts.length,
      ordertype: selected,
      schedule: scheduleSelected,
      orderPlacedDate: orderdate,
      status: "PLACED",
    };

    myproducts.forEach((item) => {
      // alert(JSON.stringify(item));
      // item["orderid"] = response3.data;
      item["subtotal"] = item["price"];
      delete item.price;
      delete item.cart_Id;
      item["product_id"] = item["product_Id"];
      delete item.product_Id;
      item["orderid"] = 1000;
      // alert(JSON.stringify(item));
    });

    placeOrder["order_products"] = myproducts;
    console.log(JSON.stringify(placeOrder));
    // alert(JSON.stringify(placeOrder));


    axios
      .post("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/order/placeorder", placeOrder)

      .then((response4) => {
        alert("this is the response: " + response4.data);
      })
      .then(
        (res) => {
          // Unfortunately, fetch doesn't send (404 error)
          // into the cache itself
          // You have to send it, as I have done below
          // if (res.status >= 400) {
          //   throw new Error("Since Available Quantity is Low!!");
          // }
          //return
        },
        (err) => {
          console.log(err);
          setErr(err);
          // alert(
          //   "Since Available Quantity is Low!! The ordered quantity is reduced"
          // );
          //  navigate("/seller/home");
          setIsLoaded(true);
        }
      );

    navigate("/myorders");
  };

  const [house_no, setHouse_no] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [state, setState] = useState("");
   const [email, setemail] = useState('');
    const [firstName, setfirstname] = useState('');

  const [lastName, setlastname] = useState('');

  const [dummy, setdummy] = useState('');

  //const [country, setCountry] = useState('');

  return (
    <div>
      <Navbar />
      <div>
        <div className="container card checkout-card">
          <main>
            <div>
              <h4 className="text-center">Checkout</h4>
              <hr className="my-4 line " />
            </div>
            <div className="row g-5">
              <div className="col-md-5 col-lg-4 order-md-last">
                <h4 className="d-flex justify-content-between align-items-center mb-3">
                  <span className="line">Order Summary</span>
                  <span className="badge checkout-custom rounded-pill">
                    {myproducts.length}
                  </span>
                </h4>
                <ul className="list-group mb-3">
                  {myproducts.map((myproduct, index) => {
                    totalCartPrice += myproduct.quantity * myproduct.price;
                    return (
                      <li
                        className="list-group-item d-flex justify-content-between lh-sm"
                        key={index}
                      >
                        <div>
                          <h6 className="my-0">{myproduct.product_name}</h6>
                          <small className="text-muted">
                            Quantity = {myproduct.quantity}{" "}
                          </small>
                        </div>
                        <span className="my-1">
                          Rs.{myproduct.quantity * myproduct.price} /-
                        </span>
                      </li>
                    );
                  })}
                </ul>
                <div className="list-group-item d-flex justify-content-between">
                  <h6 className="my-0">Grand Total</h6>
                  <strong>Rs.{totalCartPrice + 220} /-</strong>
                </div>
                <small className="text-muted">Shipping&Tax (+Rs.220)</small>
              </div>

              <div className="col-md-7 col-lg-8">
                <h4 className="mb-3">Billing address</h4>
                <form>
                  <div className="row g-3">
                    <div className="col-sm-6">

                      <input type="text" className="form-control" id="firstName" placeholder="First name" required value={firstName}
                        onChange={(e) => setfirstname(e.target.value)} />
                    </div>

                    <div className="col-sm-6">
                      <input type="text" className="form-control" id="lastName" placeholder="Last name" required value={lastName}
                        onChange={(e) => setlastname(e.target.value)}/>
                    </div>

                    <div className="col-12">
                      <input type="email" className="form-control" id="email" placeholder="E-mail" value={email}
                        onChange={(e) => setemail(e.target.value)} />

                    </div>

                    <div className="col-sm-6">
                      <input
                        type="text"
                        className="form-control"
                        id="houseNo"
                        placeholder="House/Flat No."
                        value={house_no}
                        onChange={(e) => setHouse_no(e.target.value)}
                      />
                    </div>

                    <div className="col-sm-6">
                      <input
                        type="text"
                        className="form-control"
                        id="street"
                        placeholder="Street"
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                      />
                    </div>

                    <div className="col-md-5">
                      <input
                        type="text"
                        className="form-control"
                        id="state"
                        placeholder="State"
                        alue={state}
                        onChange={(e) => setState(e.target.value)}
                      />
                    </div>

                    <div className="col-md-4">
                      <input
                        type="text"
                        className="form-control"
                        id="city"
                        placeholder="City"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                      />
                    </div>

                    <div className="col-md-3">
                      <input
                        type="text"
                        className="form-control"
                        id="zip"
                        placeholder="Pincode"
                        value={pincode}
                        onChange={(e) => setPincode(e.target.value)}
                      />
                    </div>
                  </div>

                  <hr className="my-4 line " />

                  <h4 className="mb-3">Choose your order type</h4>
                  <form>
                    <script
                      src="https://checkout.razorpay.com/v1/payment-button.js"
                      data-payment_button_id="pl_JwMqDPRzuRbtXP"
                      async
                    >
                      {" "}
                    </script>{" "}
                  </form>

                  <div className="row g-3 my-3">
                    <div className="col-sm-6 form-check">
                      <input
                        id="normal"
                        name="orderType"
                        type="radio"
                        className="form-check-input"
                        onChange={handleChange}
                        checked={selected === "NORMAL"}
                        value="NORMAL"
                        required
                        defaultChecked
                      />
                      <label className="form-check-label" for="normal">
                        Normal order
                      </label>
                    </div>
                    <div className="col-sm-6 form-check">
                      <input
                        id="schedule"
                        name="orderType"
                        type="radio"
                        className="form-check-input"
                        onChange={handleChange}
                        checked={selected === "SCHEDULE"}
                        value="SCHEDULE"
                        required
                      />
                      <label className="form-check-label" for="schedule">
                        Schedule your order
                      </label>
                    </div>
                  </div>

                  <div className="row g-3 my-3" id="freq_div">
                    <div className="col-sm-6">
                      <label for="schedule" className="form-label">
                        Select the frequency of your order
                      </label>
                    </div>

                    <div className="col-sm-6">
                      <select
                        className="form-select"
                        id="frequency"
                        onChange={schedulePreference}
                      >
                        <option selected>choose... </option>
                        <option value="DAILY">Daily</option>
                        <option value="WEEKLY">Weekly</option>
                        <option value="MONTHLY">Monthly</option>
                        <option value="YEARLY">Yearly</option>
                      </select>
                    </div>
                  </div>

                


                  <hr className="my-4 line " />






                  <hr className="my-4 line " />
                </form>
                <a className="App-link" onClick={displayRazorpay} target="_blank" rel="noopener noreferrer">
					


                  {/* <button className="w-100 btn btn-danger rounded-pill py-2 d-md-block" onClick={proceedtoCheckout} */}
                  <button className="w-100 btn btn-danger rounded-pill py-2 d-md-block" m>PLACE YOUR ORDER</button>
				          </a>
              </div>
            </div>
          </main>
        </div>
      </div>
      <script>
        document.getElementById('freq_div').style.display ='none';
      </script>
    </div>
  );
}

export default Checkout;
