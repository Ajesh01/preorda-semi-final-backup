import React, { useState, useEffect } from 'react';
import './Cartpage.css';
import Navbar from '../Navbar/Navbar';
var user = localStorage.getItem("user_id");
function Cartpage() {


    const [myproducts, setmyproducts] = useState([]);
    var totalCartPrice = 0;
    var updateIncrement = 1;
    var updateDecrement = -1;
    //var isCartEmpty = 0;

    useEffect(() => {
        let mounted = true;
        console.log("USER", user);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/myproducts/" +
            user, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            //console.log("data", data);
            if (mounted)
                setmyproducts(data);
            console.log("setmyproducts - length of cart", myproducts.length);
            //isCartEmpty = myproducts.length;
        })

        return () => mounted = false;
    }, []);

    const increment = (c_id, index) => {
        setmyproducts(myproducts =>
            myproducts.map((myproduct) =>
                c_id === myproduct.cart_Id ? { ...myproduct, quantity: myproduct.quantity + 1 } : myproduct
            )
        );
        console.log("incremented", myproducts[index]);
        updateMyCart(c_id, index, updateIncrement);

    };

    const decrement = (c_id, index) => {
        setmyproducts(myproducts =>
            myproducts.map((myproduct) =>
                c_id === myproduct.cart_Id ? { ...myproduct, quantity: myproduct.quantity - 1 } : myproduct
            )
        );
        console.log("decremented", myproducts[index]);
        console.log("Total number of items", myproducts.length);
        updateMyCart(c_id, index, updateDecrement);
    };
    const updateMyCart = (c_id, index, updatedQuantity) => {
        const updateCart = {
            "cart_Id": myproducts[index].cart_Id,
            "user": user, //localstorage.getITem()
            "product_Id": myproducts[index].product_Id,
            "product_name": myproducts[index].product_name,
            "quantity": myproducts[index].quantity + updatedQuantity,
            "price": myproducts[index].price
        }
        console.log("Total number of items", updateCart, updatedQuantity);

        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/update/" + myproducts[index].cart_Id, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updateCart)

        }).then(() => {

            console.log(" Cart updated successfully");

        })

    };

    function removeFromCart(id) {
        console.log(id);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/myproducts/" +
            id, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },

        }).then(() => {
            alert("Removed from cart");
            fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/cart/myproducts/" +
                user, {
                method: "GET",
                headers: { "Content-Type": "application/json" }
                // body: JSON.stringify(sellermyproducts)

            }).then(async response => {
                const data = await response.json();
                console.log(data);
                //if(mounted)
                setmyproducts(data)

            });
        })
    };
    var CART_HTML = '';
    if (myproducts.length > 0) {
        CART_HTML =
            <div className="container px-4 px-lg-5 my-5">
                <div className="row">
                    <div className="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">


                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="p-2 px-3 text-uppercase">Product</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Price</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Quantity</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Subtotal</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Remove</div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        myproducts.map((myproduct, index) => {
                                            totalCartPrice += myproduct.quantity * myproduct.price;
                                            return (
                                                <tr key={index}>
                                                    <th scope="row">
                                                        <div className="p-2">
                                                            <img src="https://therichpost.com/wp-content/uploads/2021/05/dummyimage400x300.jpg" alt="" width="70" className="img-fluid rounded shadow-sm" />
                                                            <div className="ms-3 d-inline-block align-middle">
                                                                <h5 className="mb-0"><a href="#" className="text-dark d-inline-block">{myproduct.product_name}</a></h5>
                                                            </div>
                                                        </div>
                                                    </th>
                                                    <td className="align-middle"><strong><span className="WebRupee">&#x20B9;</span>{myproduct.price}</strong></td>
                                                    <td className="align-middle">
                                                        <span>
                                                            <button className="badge checkout-custom rounded-pill" type="submit"
                                                                onClick={() => decrement(myproduct.cart_Id, index)}>-</button>
                                                        </span>
                                                        <strong><span> {myproduct.quantity} </span></strong>
                                                        <span>
                                                            <button className="badge checkout-custom rounded-pill" type="submit"
                                                                onClick={() => increment(myproduct.cart_Id, index)}>+</button>
                                                        </span>
                                                    </td>
                                                    <td className="align-middle"><strong><span className="WebRupee">&#x20B9;</span>{myproduct.price * myproduct.quantity}</strong></td>
                                                    <td className="align-middle"><a href='#' className='btn btn-danger' onClick={e => removeFromCart(myproduct.cart_Id)}>Remove</a></td>
                                                    <td className="align-middle"><a href="#" className="text-dark"><i className="bi bi-trash"></i></a>
                                                    </td>
                                                </tr>
                                            )
                                        })}

                                </tbody>

                            </table>

                        </div>
                    </div>
                </div>

                <div className="row py-5 p-4 bg-white rounded shadow-xs">

                    <div className="col-lg">
                        <div className="bg-light rounded-pill px-4 py-3 text-uppercase fw-bold text-center">Order summary </div>
                        <div className="p-4">
                            <p className="mb-4 text-center"><em>Shipping and delivery charges will be added.</em></p>
                            <ul className="list-unstyled mb-4">
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Subtotal
                                </strong><strong><span className="WebRupee">&#x20B9;</span>{totalCartPrice}</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Shipping cost
                                </strong><strong><span className="WebRupee">&#x20B9;</span>150</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Tax
                                </strong><strong><span className="WebRupee">&#x20B9;</span>70</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Grand Total</strong>
                                    <h5 className="fw-bold"><span className="WebRupee">&#x20B9;</span>{totalCartPrice + 220}</h5>
                                </li>
                            </ul><a href="/cart/checkout" className="btn btn-danger rounded-pill py-2 d-md-block">Procceed to checkout</a>
                        </div>
                    </div>
                </div>

            </div>
    }
    else {
        CART_HTML = <div style={{ minHeight: '85vh' }}>

            <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '55vh' }} >
                <div class="card p-3 text-center py-4 seller-card" id="sell_reg"><h3 className='text-center'>Cart is Empty</h3>
                    <a href="/products" className="btn btn-danger rounded-pill py-2 d-md-block" >Add more products</a>
                </div>
            </div>
        </div>

    }

    return (
        <div>
            <Navbar />
            <section className="py-auto">
                {CART_HTML}
            </section>
        </div>

    )
}

export default Cartpage;